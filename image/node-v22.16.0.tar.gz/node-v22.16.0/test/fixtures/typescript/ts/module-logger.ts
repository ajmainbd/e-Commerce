export const logger = (): void => { };
