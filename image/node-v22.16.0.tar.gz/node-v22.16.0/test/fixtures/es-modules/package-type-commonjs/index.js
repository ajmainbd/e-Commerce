const identifier = 'package-type-commonjs';
console.log(identifier);
module.exports = identifier;
