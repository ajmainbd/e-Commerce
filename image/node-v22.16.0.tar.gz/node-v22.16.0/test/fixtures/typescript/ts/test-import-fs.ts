import fs from 'fs';
console.log('Hello, TypeScript!');
