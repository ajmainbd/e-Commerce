function foo(): string {
  await Promise.resolve(1);
}
