const { foo } = require('../mts/test-mts-export-foo.mts');

interface Foo { };

console.log(foo);
