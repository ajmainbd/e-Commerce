module.exports = require('./a.mjs');
