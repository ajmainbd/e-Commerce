import { foo } from './test-no-extensions';

interface Foo {};

console.log(foo);
