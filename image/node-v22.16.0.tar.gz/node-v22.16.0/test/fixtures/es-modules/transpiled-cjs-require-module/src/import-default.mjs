import Logger from 'logger';
new Logger().log('import default');
