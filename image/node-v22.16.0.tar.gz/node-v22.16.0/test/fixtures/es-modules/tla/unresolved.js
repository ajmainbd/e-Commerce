await new Promise(() => {});
