'use strict';
require('./reference-error.mjs');
