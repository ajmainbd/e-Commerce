throw 'string';
