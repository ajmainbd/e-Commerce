import { register } from 'node:module';
import * as fixtures from '../../../common/fixtures.mjs';

register(fixtures.fileURL('typescript/ts/hook.ts'));
