// Reference errors are not thrown until reference happens.
console.log('executed');
module.exports = { hello: 'world' };
