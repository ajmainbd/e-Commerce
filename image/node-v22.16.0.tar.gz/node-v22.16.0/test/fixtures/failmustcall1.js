const common = require('../common');
const f = common.mustCall( () => {}, 2);
f();
