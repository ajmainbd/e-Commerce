namespace Greeting {
    export function sayHello(name: string) {
        return `Hello, ${name}!`;
    }
}

console.log(Greeting.sayHello("TypeScript!"));
