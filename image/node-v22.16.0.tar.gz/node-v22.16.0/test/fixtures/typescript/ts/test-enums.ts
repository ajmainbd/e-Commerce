enum Color {
  Red,
  Green,
  Blue,
}

console.log(Color.Red);
console.log(Color.Green);
console.log(Color.Blue);

console.log(Color[0]);
console.log(Color[1]);
console.log(Color[2]);
