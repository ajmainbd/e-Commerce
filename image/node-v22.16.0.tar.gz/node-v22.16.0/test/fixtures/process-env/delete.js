delete process.env.FOO;
