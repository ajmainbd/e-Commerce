import { add, addImported } from './simple.wasm';
import { state } from './wasm-dep.mjs';
