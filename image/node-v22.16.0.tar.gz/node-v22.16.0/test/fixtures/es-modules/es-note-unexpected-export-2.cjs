const config = 10;
export {
  config
};
