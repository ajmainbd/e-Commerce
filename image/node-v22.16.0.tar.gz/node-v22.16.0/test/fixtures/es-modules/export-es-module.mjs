export const __esModule = 'test';
export default { hello: 'world' };
