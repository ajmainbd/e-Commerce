Object.defineProperty(exports, "__esModule", { value: true });
require('./warning-esm-transpiled-b.js');
