const { foo } = require('./test-commonjs-export');

console.log(foo);
