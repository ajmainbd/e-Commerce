export type MyType = {
  foo: string;
};
