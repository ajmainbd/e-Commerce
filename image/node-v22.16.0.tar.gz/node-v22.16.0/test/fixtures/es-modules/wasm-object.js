export const { get: getProperty, set: setProperty } = Reflect;
export const { create } = Object;
export const global = globalThis;
