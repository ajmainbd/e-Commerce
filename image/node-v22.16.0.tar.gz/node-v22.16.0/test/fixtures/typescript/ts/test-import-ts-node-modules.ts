import { bar } from 'bar';

interface Bar {};

console.log(bar);
