const foo: string = 'Hello, TypeScript!';

module.exports = { foo };
