const example = 10;
export default example;
