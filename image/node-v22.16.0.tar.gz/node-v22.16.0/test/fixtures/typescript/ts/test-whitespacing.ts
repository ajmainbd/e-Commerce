interface Foo {
  bar: string;
}

throw new Error("Whitespacing");
