const { foo } = require('../mts/test-mts-export-foo.mts');

console.log(foo);
