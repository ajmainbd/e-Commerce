const str: string = "Hello, TypeScript!";
interface Foo {
  bar: string;
}
console.log(str);
