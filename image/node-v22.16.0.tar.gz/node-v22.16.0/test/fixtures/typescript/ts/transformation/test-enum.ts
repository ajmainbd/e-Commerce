enum Foo {
    A = "Hello, TypeScript!",
}
console.log(Foo.A);
