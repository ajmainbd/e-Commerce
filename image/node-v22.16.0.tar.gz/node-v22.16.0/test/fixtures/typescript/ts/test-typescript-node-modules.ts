import { foo } from 'foo';

console.log(foo);
