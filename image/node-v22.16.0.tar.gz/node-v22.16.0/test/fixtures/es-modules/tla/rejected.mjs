await Promise.reject(new Error('Xyz'));
