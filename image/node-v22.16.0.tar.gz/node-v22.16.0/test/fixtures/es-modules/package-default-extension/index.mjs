export const entry = 'mjs';
