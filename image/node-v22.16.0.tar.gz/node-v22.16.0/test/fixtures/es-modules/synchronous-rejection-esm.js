import 'node:fs';  // Forces it to be recognized as ESM.
Promise.reject('reject!');
