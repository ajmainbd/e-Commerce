// b.mjs
import "./c.mjs";
console.log("Execute b");
