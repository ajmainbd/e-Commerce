import 'node:fs';  // Forces it to be recognized as ESM.
throw new Error('hello');
