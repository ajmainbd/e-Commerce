import result from './b.cjs';
export default 'hello';
console.log('import b.cjs from a.mjs', result);
