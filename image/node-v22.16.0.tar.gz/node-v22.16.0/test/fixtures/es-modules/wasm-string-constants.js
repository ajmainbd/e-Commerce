const console = 'console';
const hello_world = 'hello world';
const log = 'log';
const prop = 'prop';

export { console, hello_world as 'hello world', log, prop }
