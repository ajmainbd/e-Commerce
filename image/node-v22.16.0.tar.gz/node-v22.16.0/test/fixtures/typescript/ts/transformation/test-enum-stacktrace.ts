enum Foo {
    A = "Hello, TypeScript!",
}
throw new Error(Foo.A);
