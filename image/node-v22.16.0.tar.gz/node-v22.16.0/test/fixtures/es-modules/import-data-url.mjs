import "data:text/javascript;export * from \"node:os\"";
