import 'pkg/folder/m.js';
