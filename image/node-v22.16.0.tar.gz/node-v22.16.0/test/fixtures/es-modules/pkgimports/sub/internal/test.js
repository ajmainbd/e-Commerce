'use strict';

module.exports = 'internal only';
