const a = require('./warning-a.js');
a.missingPropB;
a[Symbol('someSymbol')];
